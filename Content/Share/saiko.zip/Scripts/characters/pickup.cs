using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using viva;


public class PickupTest: VivaScript{

	private readonly Character character;
	private Item[] oldListenItems;
	private Item cached;
	private float lastGiddyTime;


	public PickupTest( Character _character ){
		character = _character;
		
		character.biped.vision.onItemSeen.AddListener( this, OnNewItemSeen );
		character.biped.lookTarget.onChanged.AddListener( this, OnLookTargetChange );
		character.onGesture.AddListener( this, ListenForStopGesture );
    }

    private void ListenForStopGesture( string gesture, Character source ){
        if( gesture == "stop" ){
			StopPickupTask( "pickup beingOffered right" );
			StopPickupTask( "pickup beingOffered left" );
        }
	}

	private void StopPickupTask( string offerTaskName ){
		var oldTask = character.autonomy.FindTask( offerTaskName ) as Pickup;
		if( oldTask != null ){
			oldTask.Fail("Stopped task");
			character.autonomy.RemoveTask( oldTask );
		}
	}

	private void OnNewItemSeen( Item item ){
		CheckForPickup( item.rigidBody );
	}

	private void OnLookTargetChange(){
		var rigidBody = character.biped.lookTarget.target as Rigidbody;
		CheckForPickup( rigidBody );

		//if failed to pick up, listen for the lookCharacter's held items
		var lookCharacter = Util.GetCharacter( rigidBody );
		if( lookCharacter && lookCharacter.isBiped ){
			var heldItems = new List<Item>();
			heldItems.AddRange( lookCharacter.biped.rightHandGrabber.GetAllItems() );
			heldItems.AddRange( lookCharacter.biped.leftHandGrabber.GetAllItems() );
			SetListenForAttributeChanged( heldItems.ToArray() );
		}
	}

	private void CheckForPickup( Rigidbody rigidBody ){
		if( !rigidBody ){
			return;
		}

		//character must not be performing any other task (to prevent task interruptions)
		if( !character.autonomy.HasTag( "idle" ) ) return;
		var item = rigidBody.GetComponent<Item>();
		if( !item ){
			
			//check if rigidBody being looked at is holding an item being offered
			var otherCharacter = Util.GetCharacter( rigidBody );
			if( otherCharacter && otherCharacter.isBiped && otherCharacter != character ){ //dont check self
				var context = otherCharacter.biped.rightHandGrabber.IsGrabbing( Item.offerAttribute );
				if( context && PickupItem( context.grabbable.parentItem ) ){
					return;
				}
				context = otherCharacter.biped.leftHandGrabber.IsGrabbing( Item.offerAttribute );
				if( context && PickupItem( context.grabbable.parentItem ) ){
					return;
				}
			}
			return;
		}

		if( !PickupItem( item ) ){
			//else just listen to the item
			SetListenForAttributeChanged( new Item[]{ item } );
		}
	}

	private void SetListenForAttributeChanged( Item[] items ){
		if( oldListenItems != null ){
			foreach( var oldItem in oldListenItems ){
				if( oldItem ) oldItem.onAttributeChanged.RemoveListener( this, OnItemAttributeAdded );
			}
			oldListenItems = null;
		}
		oldListenItems = items;
		if( items != null ){
			foreach( var newItem in items ){
				if( newItem ) newItem.onAttributeChanged.AddListener( this, OnItemAttributeAdded );
			}
		}
	}

	private void OnItemAttributeAdded( Item item, Attribute attribute ){
		if( attribute.name == Item.offerAttribute ){
			PickupItem( item );
		}
	}

	private bool PickupItem( Item item ){
		if( item == null ) return false;
		if( !item.HasAttribute(Item.offerAttribute) ) return false;
		if( cached != null && item == cached ) return false;

		if( !character.autonomy.HasTag( "idle" ) ) return false;

		//hands must be free
		if( character.biped.rightHandGrabber.grabbing && character.biped.leftHandGrabber.grabbing ){
			return false;
		}
		//dont pick up if already grabbing it
		if( AmIGrabbing( item ) ) return false;

		//dont pick up if it doesnt have any grabbables
		if( item.grabbableCount == 0 ) return false ;

		var targetGrabbable = item.grabbables[0];
		var pickup = new Pickup( character.autonomy, targetGrabbable );
		// pickup.tags.Add("idle");
		var offerTaskName = "pickup beingOffered "+pickup.grabber?.signName;

		var oldTask = character.autonomy.FindTask( offerTaskName ) as Pickup;
		if( oldTask != null ){
			if( CalculateInterest( oldTask.grabbable?.parentItem ) >= CalculateInterest( item ) ){
				return false;
			}
			oldTask.Fail("Saw more interesting item to pickup");
			character.autonomy.RemoveTask( oldTask );
		}

		SetupAnimations( character );
		SetListenForAttributeChanged( null );

		//create the autonomy task
		cached = item;
		//if item is picked up
		pickup.onSuccess += delegate{
			item?.ClearAttribute( Item.offerAttribute );
		};
		pickup.onAutonomyExit += delegate{
			cached = null;
		};

		pickup.moveTo.onRegistered += delegate{
			character.biped.lookTarget.SetTargetRigidBody( item?.rigidBody );
		};
		
		var ensureItemExists = new Condition( character.autonomy, delegate{
			return item && item.HasAttribute( Item.offerAttribute );
		} );
		pickup.AddRequirement( ensureItemExists );

		if( Random.value > 0.3f && Time.time-lastGiddyTime > 10f && character.mainAnimationLayer.currentBodySet["giddy"] != null ){
			lastGiddyTime = Time.time;
			var playGiddyAnimation = new PlayAnimation( character.autonomy, null, "giddy", true, 0, null );
			playGiddyAnimation.name = "giddy before pickup";
			playGiddyAnimation.onEnterAnimation += delegate{
				character.biped.lookTarget.SetTargetRigidBody( item?.rigidBody );
			};
			playGiddyAnimation.onExitAnimation += playGiddyAnimation.Succeed;
			
			pickup.AddRequirement( playGiddyAnimation );

			var faceItem = new FaceTargetBody( character.autonomy, 1, 30, 0.3f );
			faceItem.target.SetTargetRigidBody( item.rigidBody );
			playGiddyAnimation.AddPassive( faceItem );
		}
		
		pickup.Start( this, offerTaskName );
		return true;
	}

	private float CalculateInterest( Item item ){
		if( item == null ) return 0;
		int interest = 0;
		foreach( var grabbable in item.grabbables ){
			if( grabbable.isBeingGrabbed ) interest++;
		}
		return interest;
	}

	private void SetupAnimations( Character character ){
		var stand = character.animationSet["stand"];
		var standGiddy = new AnimationSingle( viva.Animation.Load("stand_giddy_surprise"), character, false );
		standGiddy.AddEvent( Event.Voice(0,"impressed") );
		standGiddy.nextState = stand["idle"];
		stand["giddy"] = standGiddy;
	}

	private bool AmIGrabbing( Item item ){
		return character.biped.rightHandGrabber.IsGrabbing( item ) || character.biped.leftHandGrabber.IsGrabbing( item );
	}
}  