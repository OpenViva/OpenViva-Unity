using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using viva;


public class Snack: VivaScript{

	private readonly Character character;
	private Item targetSnack;

	public Snack( Character _character ){
		character = _character;

		SetupAnimations();

		var snackListener = new Task( character.autonomy );
		snackListener.onFixedUpdate += delegate{

			var lookAtItem = character.biped.vision.GetCurrentItem();
			CheckCanSnack( lookAtItem );
		};
		snackListener.StartConstant( this, "listen for snacks");
	}

	private void SetupAnimations(){

		var stand = character.animationSet["stand"];

		var standSnackOut = new AnimationSingle( viva.Animation.Load("stand_feed_out"), character, false );
		standSnackOut.nextState = stand["idle"];
		stand["snack out"] = standSnackOut;

		var standSnackLoop = new AnimationSingle( viva.Animation.Load("stand_feed_loop"), character, true );
		standSnackLoop.curves.Add( BipedRagdoll.headID, new Curve( 0.3f ) );
		stand["snack loop"] = standSnackLoop;

		var standSnackIn = new AnimationSingle( viva.Animation.Load("stand_feed_in"), character, false );
		standSnackIn.curves.Add( BipedRagdoll.headID, new Curve( 0.0f ) );
		standSnackIn.nextState = standSnackLoop;
		stand["snack in"] = standSnackIn;

		var standSnackSuccess = new AnimationSingle( viva.Animation.Load("stand_feed_success"), character, false );
		standSnackSuccess.curves.Add( BipedRagdoll.headID, new Curve(0) );
		standSnackSuccess.nextState = stand["idle"];
		standSnackSuccess.AddEvent( Event.Voice(0,"eat"));
		standSnackSuccess.AddEvent( Event.Function(0.1f,EatSnack));
		stand["snack success"] = standSnackSuccess;
	}

	private void EatSnack(){
		if( !targetSnack ) return;
		Viva.Destroy( targetSnack );
	}

	private bool InRangeForEating( Item item, float rangeMult ){
		if( !item ) return false;
		var headRadius = character.biped.CalculateMuscleBoundingSphere( character.biped.head );
		var head = character.biped.head.rigidBody;
		var headDistance = Vector3.Distance( head.worldCenterOfMass, item.rigidBody.worldCenterOfMass );
		headDistance -= headRadius;
		if( headDistance > headRadius*rangeMult ) return false;
		return Vector3.Dot( head.transform.forward, (item.rigidBody.worldCenterOfMass-head.worldCenterOfMass).normalized ) > 0.7f;
	}

	private void CheckCanSnack( Item item ){
		if( !item ) return;
		//make sure current animation can play snack animation
		if( character.mainAnimationLayer.currentBodySet["snack in"] == null ) return;
		if( character.IsGrabbing( item ) ) return;
		if( !item.HasAttribute("snack") ) return;
		if( !character.autonomy.HasTag("idle") ) return;
		if( !InRangeForEating( item, 2.5f ) ) return;
		if( character.autonomy.FindTask("snack") != null ) return;

		targetSnack = item;
		var leanInForSnackAnim = new PlayAnimation( character.autonomy, null, "snack loop", true, 0, null );

		var waitForSnack = new PlayAnimation( character.autonomy, null, "snack loop", true, -1 );
		waitForSnack.AddRequirement( leanInForSnackAnim );

		var faceSnack = new FaceTargetBody( character.autonomy );
		faceSnack.target.SetTargetRigidBody( targetSnack.rigidBody );
		waitForSnack.AddPassive( faceSnack );

		var outOfRangeTimer = 0f;
		waitForSnack.onFixedUpdate += delegate{
			if( !InRangeForEating( targetSnack, 3f ) ){
				outOfRangeTimer += Time.deltaTime;
				if( outOfRangeTimer > 0.5f ){
					waitForSnack.Fail("snack too far");

					var exitSnackAnim = new PlayAnimation( character.autonomy, null, "snack out", true, 1, "snack loop" );
					exitSnackAnim.Start( this, "stop snack in" );
				}
			}else{
				outOfRangeTimer = 0f;
				if( InRangeForEating( targetSnack, 0.5f ) ){
					waitForSnack.Succeed();
					
					var exitSnackAnim = new PlayAnimation( character.autonomy, null, "snack success", true, 1, "snack loop" );
					exitSnackAnim.transitionTime = 0.05f;
					exitSnackAnim.tags.Add("disable poke");
					exitSnackAnim.tags.Add("disable headpat");
					exitSnackAnim.Start( this, "stop snack in" );
				}
			}
		};

		waitForSnack.tags.Add("disable poke");
		waitForSnack.Start(this,"snack");
	}
}  